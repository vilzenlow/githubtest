/* Frmvrfy.js v1.2 - Part of BadStore.net */

function DoPwdvrfy(x)
{

var pwd = (x["newpasswd"].value);
var vpwd = (x["vnewpasswd"].value);
if(pwd != vpwd){
	alert('The password values do not match!');
return false;
}else{
return true;
}
} 
